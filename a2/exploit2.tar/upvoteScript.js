function fn(content) {
  var aTags = document.querySelectorAll(body);
  var foundTag;
  for (var i = aTags.length - 1; i >= 0; i--) {
    if (aTags[i].textContent === content) {
      foundTag = aTags[i];
      break;
    }
  }
  var postID = foundTag.match(content);
  var request = new XMLHttpRequest();
  request.open("POST", 'http://ugster05.student.cs.uwaterloo.ca/h343chen', true);
  request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  request.send("id="+postID+"&vote=1");
}
fn('Auto Upvoting Bot');
